﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using System.Data;
using System.Data.SqlClient; 

namespace DataAccessLayer
{
    public class DALMusteri
    {

        public static int musteriEkle( EntityMusteri p )
        {
            SqlCommand komut = new SqlCommand("insert into tblMusteriler (ad, soyad, adres, tel) values (@p1, @p2, @p3, @p4)  ", Baglanti.baglan );
            if (komut.Connection.State != ConnectionState.Open )
            {
                komut.Connection.Open(); 
            }
            komut.Parameters.AddWithValue("@p1", p.Ad);
            komut.Parameters.AddWithValue("@p2", p.Soyad);
            komut.Parameters.AddWithValue("@p3", p.Adres);
            komut.Parameters.AddWithValue("@p4", p.Tel);

            return komut.ExecuteNonQuery(); 

        }

        public static int musteriSil (EntityMusteri p)
        {
            SqlCommand komut = new SqlCommand("delete from  tblMusteriler where MusteriID = @p1", Baglanti.baglan);
            if (komut.Connection.State != ConnectionState.Open)
            {
                komut.Connection.Open();
            }
            komut.Parameters.AddWithValue("@p1", p.MusteriID);

            return komut.ExecuteNonQuery();
        }

        public static int musteriGuncelle (EntityMusteri p)
        {
            SqlCommand komut = new SqlCommand("update  tblMusteriler set ad= @p1, soyad = @p2, adres = @p3, tel = @p4 where MusteriID= @p5  ", Baglanti.baglan);
            if (komut.Connection.State != ConnectionState.Open)
            {
                komut.Connection.Open();
            }
            komut.Parameters.AddWithValue("@p1", p.Ad);
            komut.Parameters.AddWithValue("@p2", p.Soyad);
            komut.Parameters.AddWithValue("@p3", p.Adres);
            komut.Parameters.AddWithValue("@p4", p.Tel);
            komut.Parameters.AddWithValue("@p5", p.MusteriID);

            return komut.ExecuteNonQuery();

        }

        public static List<EntityMusteri>  musteriListele ( )
        {
            SqlCommand komut = new SqlCommand("select * from TblMusteriler ", Baglanti.baglan);
            if (komut.Connection.State != ConnectionState.Open)
            {
                komut.Connection.Open();
            }

            SqlDataReader dr = komut.ExecuteReader();

            List<EntityMusteri> musteriler = new List<EntityMusteri>(); 

            while (dr.Read() )
            {
                EntityMusteri ent = new EntityMusteri();
                ent.MusteriID = int.Parse(dr[0].ToString());
                ent.Ad = dr[1].ToString();
                ent.Soyad = dr[2].ToString();
                ent.Adres = dr[3].ToString();
                ent.Tel = dr[4].ToString();

                musteriler.Add(ent); 
            }

            dr.Close(); 
            return musteriler; 

        }



    }
}
