﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using System.Data;
using System.Data.SqlClient; 


namespace DataAccessLayer
{
    public  class Baglanti
    {
        public static SqlConnection baglan = new SqlConnection("server = .\\SQLEXPRESS; initial catalog = DbKatmanliM; integrated security = true   "); 

    }
}
