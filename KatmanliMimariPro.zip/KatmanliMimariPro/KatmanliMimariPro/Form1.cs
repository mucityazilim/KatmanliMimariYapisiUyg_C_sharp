﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntityLayer;
using DataAccessLayer;
using BusinesLayer; 


namespace KatmanliMimariPro
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        void listele()
        {
            dataGridView1.DataSource = BLMusteri.musteriListele();
            txtID.Text = "";
            txtAd.Text = "";
            txtSoyad.Text = "";
            txtAdres.Text = "";
            txtTel.Text = ""; 
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listele(); 
        }

        private void btnListele_Click(object sender, EventArgs e)
        {
            listele(); 
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (txtTel.Text == "" || txtSoyad.Text=="")
            {
                MessageBox.Show("Lütfen tüm alanları giriniz ", "Hata");
            }
            else
            {
                EntityMusteri eleman = new EntityMusteri();
                eleman.Ad = txtAd.Text;
                eleman.Soyad = txtSoyad.Text;
                eleman.Adres = txtAdres.Text;
                eleman.Tel = txtTel.Text;
                BLMusteri.musteriEkle(eleman);

                MessageBox.Show("kayıt tamam");
            }
            listele(); 

        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Lütfen silinecek kişiyi seçiniz ", "Hata");
            }
            else
            {
                EntityMusteri eleman = new EntityMusteri();
                eleman.MusteriID = int.Parse( txtID.Text ) ; 
                BLMusteri.musteriSil(eleman);

                MessageBox.Show("Silme işlemi tamam");
            }
            listele();

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtAd.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtSoyad.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtAdres.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtTel.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();

        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (txtTel.Text == "" || txtSoyad.Text == "")
            {
                MessageBox.Show("Lütfen tüm alanları giriniz ", "Hata");
            }
            else
            {
                EntityMusteri eleman = new EntityMusteri();
                eleman.MusteriID = int.Parse(txtID.Text); 
                eleman.Ad = txtAd.Text;
                eleman.Soyad = txtSoyad.Text;
                eleman.Adres = txtAdres.Text;
                eleman.Tel = txtTel.Text;
                BLMusteri.musteriGuncelle (eleman);

                MessageBox.Show("güncelleme tamam");
            }
            listele();


        }
    }
}
