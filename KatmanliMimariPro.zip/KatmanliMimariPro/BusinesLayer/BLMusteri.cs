﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using DataAccessLayer; 


namespace BusinesLayer
{
    public class BLMusteri
    {
        public static int musteriEkle(EntityMusteri p )
        {
            if ( p.Ad != null && p.Soyad != null && p.Ad.Length >2 && p.Ad.Length <50 && p.Adres != null && p.Tel != null  )
                return DALMusteri.musteriEkle(p);
            return -1; 
        }
        public static int musteriSil(EntityMusteri p)
        {
            if (p.MusteriID >0 )
                return DALMusteri.musteriSil(p);
            return -1;
        }
        public static int musteriGuncelle (EntityMusteri p)
        {
            if (p.Ad != null && p.Soyad != null && p.Ad.Length > 2 && p.Ad.Length < 50 && p.Adres != null && p.Tel != null && p.MusteriID>0 )
                return DALMusteri.musteriGuncelle(p);
            return -1;
        }

        public static List<EntityMusteri> musteriListele ( )
        {
            return DALMusteri.musteriListele();  

        }



    }
}
